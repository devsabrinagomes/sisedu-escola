export default function Gabaritos() {
  return <div className="text-slate-800">Gabaritos (em construção)</div>
}

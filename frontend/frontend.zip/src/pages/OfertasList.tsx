export default function OfertasList() {
  return <div className="text-slate-800">Ofertas (em construção)</div>
}

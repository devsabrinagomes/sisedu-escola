export default function CadernosList() {
  return <div className="text-slate-800">Cadernos (em construção)</div>
}

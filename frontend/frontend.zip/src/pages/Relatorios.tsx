export default function Relatorios() {
  return <div className="text-slate-800">Relatórios (em construção)</div>
}

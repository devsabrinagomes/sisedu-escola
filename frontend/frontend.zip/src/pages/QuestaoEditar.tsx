import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../lib/api";
import type { Alternativa, Disciplina } from "../types/core";

import RichEditor, {
  useRichEditor,
  hasMeaningfulHtml,
  normalizeHtml,
} from "../components/RichEditor";
import Accordion from "../components/Accordion";

type AlternativaOrEmpty = Alternativa | "";
type AltKey = "A" | "B" | "C" | "D" | "E";
const ALT_KEYS: AltKey[] = ["A", "B", "C", "D", "E"];
const ALTS: Alternativa[] = ["A", "B", "C", "D", "E"];

type Saber = { id: number; codigo: string; titulo: string; disciplina: number };
type Habilidade = { id: number; codigo: string; titulo: string; saber: number };

type RespostaDTO = {
  ordem: number;
  texto_html: string;
  imagem?: string | null;
  correta: boolean;
};

function ordemToAlt(ordem: number): AltKey {
  return ordem === 1
    ? "A"
    : ordem === 2
      ? "B"
      : ordem === 3
        ? "C"
        : ordem === 4
          ? "D"
          : "E";
}

function ReqStar() {
  return <span className="text-red-600">*</span>;
}

export default function QuestaoEditar() {
  const { id } = useParams();
  const nav = useNavigate();

  const [triedSubmit, setTriedSubmit] = useState(false);

  const [disciplinas, setDisciplinas] = useState<Disciplina[]>([]);
  const [saberes, setSaberes] = useState<Saber[]>([]);
  const [habilidades, setHabilidades] = useState<Habilidade[]>([]);

  const [loading, setLoading] = useState(true);
  const [loadingDisc, setLoadingDisc] = useState(true);
  const [loadingSab, setLoadingSab] = useState(false);
  const [loadingHab, setLoadingHab] = useState(false);

  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const [disciplina, setDisciplina] = useState<number>(0);
  const [saberId, setSaberId] = useState<number | "">("");
  const [habilidadeId, setHabilidadeId] = useState<number | "">("");

  const [isPrivate, setIsPrivate] = useState(false);
  const [altCorreta, setAltCorreta] = useState<AlternativaOrEmpty>("");
  const [altAtiva, setAltAtiva] = useState<AltKey>("A");

  // apoio
  const [currentSuporteUrl, setCurrentSuporteUrl] = useState("");
  const [suporteFile, setSuporteFile] = useState<File | null>(null);
  const [suportePreview, setSuportePreview] = useState("");
  const [removeSuporte, setRemoveSuporte] = useState(false);
  const [refImagem, setRefImagem] = useState("");

  // alternativas imagens
  const [altImg, setAltImg] = useState<Record<AltKey, File | null>>({
    A: null,
    B: null,
    C: null,
    D: null,
    E: null,
  });
  const [altPreview, setAltPreview] = useState<Record<AltKey, string>>({
    A: "",
    B: "",
    C: "",
    D: "",
    E: "",
  });
  const [currentAltImgUrl, setCurrentAltImgUrl] = useState<Record<AltKey, string>>({
    A: "",
    B: "",
    C: "",
    D: "",
    E: "",
  });
  const [removeAltImg, setRemoveAltImg] = useState<Record<AltKey, boolean>>({
    A: false,
    B: false,
    C: false,
    D: false,
    E: false,
  });

  // editores
  const enunciadoEd = useRichEditor("<p></p>");
  const comandoEd = useRichEditor("<p></p>");
  const textoApoioEd = useRichEditor("<p></p>");

  const altAEd = useRichEditor("<p></p>");
  const altBEd = useRichEditor("<p></p>");
  const altCEd = useRichEditor("<p></p>");
  const altDEd = useRichEditor("<p></p>");
  const altEEd = useRichEditor("<p></p>");

  // cleanup previews
  useEffect(() => {
    return () => {
      if (suportePreview) URL.revokeObjectURL(suportePreview);
      (["A", "B", "C", "D", "E"] as AltKey[]).forEach((k) => {
        if (altPreview[k]) URL.revokeObjectURL(altPreview[k]);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // disciplinas
  useEffect(() => {
    (async () => {
      try {
        setLoadingDisc(true);
        const { data } = await api.get<Disciplina[]>("/disciplinas/");
        setDisciplinas(data);
      } finally {
        setLoadingDisc(false);
      }
    })();
  }, []);

  // saberes por disciplina
  useEffect(() => {
    if (!disciplina) {
      setSaberes([]);
      setSaberId("");
      setHabilidades([]);
      setHabilidadeId("");
      return;
    }
    (async () => {
      try {
        setLoadingSab(true);
        const { data } = await api.get<Saber[]>("/saberes/", {
          params: { disciplina },
        });
        setSaberes(data);
      } finally {
        setLoadingSab(false);
      }
    })();
  }, [disciplina]);

  // habilidades por saber
  useEffect(() => {
    if (!saberId) {
      setHabilidades([]);
      setHabilidadeId("");
      return;
    }
    (async () => {
      try {
        setLoadingHab(true);
        const { data } = await api.get<Habilidade[]>("/habilidades/", {
          params: { saber: saberId },
        });
        setHabilidades(data);
      } finally {
        setLoadingHab(false);
      }
    })();
  }, [saberId]);

  // carregar questão
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        setErr("");

        const { data } = await api.get<any>(`/questoes/${id}/`);

        setDisciplina(data.disciplina ?? 0);
        setSaberId(data.saber ?? "");
        setHabilidadeId(data.habilidade ?? "");
        setIsPrivate(!!data.is_private);

        setRefImagem(data.ref_imagem ?? "");
        setCurrentSuporteUrl(data.imagem_suporte || "");

        if (enunciadoEd.editor)
          enunciadoEd.editor.commands.setContent(data.enunciado_html || "<p></p>");
        if (comandoEd.editor)
          comandoEd.editor.commands.setContent(data.comando_html || "<p></p>");
        if (textoApoioEd.editor)
          textoApoioEd.editor.commands.setContent(data.texto_suporte_html || "<p></p>");

        const respostas: RespostaDTO[] = Array.isArray(data.respostas)
          ? data.respostas
          : [];

        const byOrdem = new Map<number, RespostaDTO>();
        for (const r of respostas) byOrdem.set(r.ordem, r);

        const r1 = byOrdem.get(1);
        const r2 = byOrdem.get(2);
        const r3 = byOrdem.get(3);
        const r4 = byOrdem.get(4);
        const r5 = byOrdem.get(5);

        if (altAEd.editor) altAEd.editor.commands.setContent(r1?.texto_html || "<p></p>");
        if (altBEd.editor) altBEd.editor.commands.setContent(r2?.texto_html || "<p></p>");
        if (altCEd.editor) altCEd.editor.commands.setContent(r3?.texto_html || "<p></p>");
        if (altDEd.editor) altDEd.editor.commands.setContent(r4?.texto_html || "<p></p>");
        if (altEEd.editor) altEEd.editor.commands.setContent(r5?.texto_html || "<p></p>");

        const correta = respostas.find((r) => r.correta);
        setAltCorreta(correta ? ordemToAlt(correta.ordem) : "");

        setCurrentAltImgUrl({
          A: r1?.imagem || "",
          B: r2?.imagem || "",
          C: r3?.imagem || "",
          D: r4?.imagem || "",
          E: r5?.imagem || "",
        });

        setAltImg({ A: null, B: null, C: null, D: null, E: null });
        setRemoveAltImg({ A: false, B: false, C: false, D: false, E: false });
        setSuporteFile(null);
        setRemoveSuporte(false);
        if (suportePreview) URL.revokeObjectURL(suportePreview);
        setSuportePreview("");
        (["A", "B", "C", "D", "E"] as AltKey[]).forEach((k) => {
          if (altPreview[k]) URL.revokeObjectURL(altPreview[k]);
        });
        setAltPreview({ A: "", B: "", C: "", D: "", E: "" });
      } catch (e: any) {
        setErr(e?.response?.data?.detail || "Não foi possível carregar a questão.");
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    id,
    enunciadoEd.editor,
    comandoEd.editor,
    textoApoioEd.editor,
    altAEd.editor,
    altBEd.editor,
    altCEd.editor,
    altDEd.editor,
    altEEd.editor,
  ]);

  const canSave = useMemo(() => {
    const enu = enunciadoEd.getHtml();
    const cmd = comandoEd.getHtml();

    const a = altAEd.getHtml();
    const b = altBEd.getHtml();
    const c = altCEd.getHtml();
    const d = altDEd.getHtml();
    const e = altEEd.getHtml();

    const filled: Record<AltKey, boolean> = {
      A:
        hasMeaningfulHtml(a) ||
        !!altImg.A ||
        (!!currentAltImgUrl.A && !removeAltImg.A),
      B:
        hasMeaningfulHtml(b) ||
        !!altImg.B ||
        (!!currentAltImgUrl.B && !removeAltImg.B),
      C:
        hasMeaningfulHtml(c) ||
        !!altImg.C ||
        (!!currentAltImgUrl.C && !removeAltImg.C),
      D:
        hasMeaningfulHtml(d) ||
        !!altImg.D ||
        (!!currentAltImgUrl.D && !removeAltImg.D),
      E:
        hasMeaningfulHtml(e) ||
        !!altImg.E ||
        (!!currentAltImgUrl.E && !removeAltImg.E),
    };

    const order: AltKey[] = ["A", "B", "C", "D", "E"];
    const lastIdx = Math.max(...order.map((k, i) => (filled[k] ? i : -1)));
    const activeCount = Object.values(filled).filter(Boolean).length;

    const minOk = filled.A && filled.B && activeCount >= 2;
    const noHoles =
      lastIdx >= 1 && order.slice(0, lastIdx + 1).every((k) => filled[k]);
    const correctOk =
      altCorreta !== "" &&
      lastIdx >= 1 &&
      order.indexOf(altCorreta as AltKey) <= lastIdx;

    return (
      !loading &&
      disciplina > 0 &&
      hasMeaningfulHtml(enu) &&
      hasMeaningfulHtml(cmd) &&
      minOk &&
      noHoles &&
      correctOk
    );
  }, [
    loading,
    disciplina,
    altCorreta,
    enunciadoEd,
    comandoEd,
    altAEd,
    altBEd,
    altCEd,
    altDEd,
    altEEd,
    altImg,
    currentAltImgUrl,
    removeAltImg,
  ]);

  function pickAltFile(key: AltKey, file: File | null) {
    setAltImg((p) => ({ ...p, [key]: file }));
    setRemoveAltImg((p) => ({ ...p, [key]: false }));

    if (altPreview[key]) URL.revokeObjectURL(altPreview[key]);
    setAltPreview((p) => ({
      ...p,
      [key]: file ? URL.createObjectURL(file) : "",
    }));
  }

  function removeAltImage(key: AltKey) {
    setRemoveAltImg((p) => ({ ...p, [key]: true }));
    setAltImg((p) => ({ ...p, [key]: null }));
    if (altPreview[key]) URL.revokeObjectURL(altPreview[key]);
    setAltPreview((p) => ({ ...p, [key]: "" }));
  }

  function buildUsedBlocks() {
    const blocks = [
      { key: "A" as const, ed: altAEd, file: altImg.A, old: currentAltImgUrl.A, rm: removeAltImg.A },
      { key: "B" as const, ed: altBEd, file: altImg.B, old: currentAltImgUrl.B, rm: removeAltImg.B },
      { key: "C" as const, ed: altCEd, file: altImg.C, old: currentAltImgUrl.C, rm: removeAltImg.C },
      { key: "D" as const, ed: altDEd, file: altImg.D, old: currentAltImgUrl.D, rm: removeAltImg.D },
      { key: "E" as const, ed: altEEd, file: altImg.E, old: currentAltImgUrl.E, rm: removeAltImg.E },
    ];

    const isFilled = (b: (typeof blocks)[number]) => {
      const html = normalizeHtml(b.ed.getHtml());
      const hasText = hasMeaningfulHtml(html);
      const hasNewImg = !!b.file;
      const hasOldImg = !!b.old && !b.rm;
      return hasText || hasNewImg || hasOldImg;
    };

    const lastIdx = Math.max(...blocks.map((b, i) => (isFilled(b) ? i : -1)));
    const n = Math.max(2, lastIdx + 1);
    return blocks.slice(0, n);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setTriedSubmit(true);
    setErr("");

    if (!hasMeaningfulHtml(comandoEd.getHtml())) {
      setErr("O comando é obrigatório.");
      return;
    }
    if (!canSave) {
      setErr("Verifique disciplina, enunciado, comando e alternativas (mínimo A e B; vazias só no final).");
      return;
    }

    try {
      setSaving(true);

      const a = altAEd.getHtml();
      const b = altBEd.getHtml();
      const c = altCEd.getHtml();
      const d = altDEd.getHtml();
      const e = altEEd.getHtml();

      const filled: Record<AltKey, boolean> = {
        A:
          hasMeaningfulHtml(a) ||
          !!altImg.A ||
          (!!currentAltImgUrl.A && !removeAltImg.A),
        B:
          hasMeaningfulHtml(b) ||
          !!altImg.B ||
          (!!currentAltImgUrl.B && !removeAltImg.B),
        C:
          hasMeaningfulHtml(c) ||
          !!altImg.C ||
          (!!currentAltImgUrl.C && !removeAltImg.C),
        D:
          hasMeaningfulHtml(d) ||
          !!altImg.D ||
          (!!currentAltImgUrl.D && !removeAltImg.D),
        E:
          hasMeaningfulHtml(e) ||
          !!altImg.E ||
          (!!currentAltImgUrl.E && !removeAltImg.E),
      };

      if (!filled.A || !filled.B) {
        setErr("As alternativas A e B são obrigatórias.");
        return;
      }

      if (!altCorreta || !filled[altCorreta as AltKey]) {
        setErr("A alternativa correta precisa estar preenchida.");
        return;
      }

      const order: AltKey[] = ["A", "B", "C", "D", "E"];

      const lastIdx = Math.max(...order.map((k, i) => (filled[k] ? i : -1)));

      if (lastIdx >= 1) {
        const noHoles = order.slice(0, lastIdx + 1).every((k) => filled[k]);

        if (!noHoles) {
          setErr("As alternativas vazias só podem ser no final (sem pular letras).");
          return;
        }
      }


      const used = buildUsedBlocks();
      if (!used.some((u) => u.key === altCorreta)) {
        setErr("A alternativa correta precisa estar preenchida.");
        return;
      }

      const respostas = used.map((u, idx) => ({
        ordem: idx + 1,
        texto_html: normalizeHtml(u.ed.getHtml()),
        correta: altCorreta === u.key,
      }));

      const fd = new FormData();
      fd.append("disciplina", String(disciplina));
      fd.append("is_private", String(isPrivate));

      fd.append("enunciado_html", normalizeHtml(enunciadoEd.getHtml()));
      fd.append("comando_html", normalizeHtml(comandoEd.getHtml()));
      fd.append("texto_suporte_html", normalizeHtml(textoApoioEd.getHtml()));
      fd.append("ref_imagem", refImagem || "");

      if (saberId) fd.append("saber", String(saberId));
      else fd.append("saber", "");
      if (habilidadeId) fd.append("habilidade", String(habilidadeId));
      else fd.append("habilidade", "");

      fd.append("respostas_payload", JSON.stringify(respostas));

      // nomes de flags dependem do teu serializer/viewset; mantive os que a gente vinha usando
      if (removeSuporte) fd.append("remove_imagem_suporte", "1");
      else if (suporteFile) fd.append("imagem_suporte", suporteFile);

      used.forEach((u, idx) => {
        const ordem = idx + 1;
        if (u.file) fd.append(`resposta_imagem_${ordem}`, u.file);
        if (u.rm) fd.append(`remove_resposta_imagem_${ordem}`, "1");
      });

      await api.patch(`/questoes/${id}/`, fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      nav("/questoes");
    } catch (e: any) {
      setErr(e?.response?.data?.detail || "Erro ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="text-sm text-slate-500">Carregando…</div>;

  const AltImagemUI = ({ keyAlt }: { keyAlt: AltKey }) => {
    const showUrl =
      altPreview[keyAlt] ||
      (!removeAltImg[keyAlt] && currentAltImgUrl[keyAlt]
        ? currentAltImgUrl[keyAlt]
        : "");

    return (
      <div className="mt-3">
        <label className="text-sm font-semibold text-slate-900">
          Imagem da alternativa {keyAlt} (opcional)
        </label>

        <div className="mt-2 flex items-start gap-4">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => pickAltFile(keyAlt, e.target.files?.[0] || null)}
            className="block w-full text-sm"
          />

          {showUrl && (
            <img
              src={showUrl}
              alt={`Imagem alternativa ${keyAlt}`}
              className="h-20 w-20 rounded-lg border border-slate-200 object-cover"
            />
          )}
        </div>

        {!!currentAltImgUrl[keyAlt] && (
          <div className="mt-2 flex items-center gap-2">
            <button
              type="button"
              onClick={() => removeAltImage(keyAlt)}
              className="text-sm text-red-600 hover:underline"
            >
              Remover imagem da alternativa {keyAlt}
            </button>
            {removeAltImg[keyAlt] && (
              <span className="text-xs text-slate-500">(vai remover ao salvar)</span>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-semibold text-slate-900">Editar questão</h1>
        <Link
          to="/questoes"
          className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
        >
          Voltar
        </Link>
      </div>

      {err && (
        <div className="rounded-lg border border-red-200 bg-red-50 text-red-700 px-4 py-3 text-sm">
          {err}
        </div>
      )}

      {/* CARD MASTER */}
      <form
        onSubmit={onSubmit}
        className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-6"
      >
        {/* Topo */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <div>
            <label className="text-sm font-semibold text-slate-900">
              Disciplina <ReqStar />
            </label>
            <select
              value={disciplina}
              disabled={loadingDisc}
              onChange={(e) => setDisciplina(Number(e.target.value))}
              className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-200"
            >
              <option value={0} disabled>
                Selecione…
              </option>
              {disciplinas.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.nome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-semibold text-slate-900">
              Saber (opcional)
            </label>
            <select
              value={saberId}
              disabled={!disciplina || loadingSab}
              onChange={(e) =>
                setSaberId(e.target.value ? Number(e.target.value) : "")
              }
              className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-200"
            >
              <option value="">Nenhum</option>
              {saberes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.codigo} — {s.titulo}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-semibold text-slate-900">
              Habilidade (opcional)
            </label>
            <select
              value={habilidadeId}
              disabled={!saberId || loadingHab}
              onChange={(e) =>
                setHabilidadeId(e.target.value ? Number(e.target.value) : "")
              }
              className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-200"
            >
              <option value="">Nenhuma</option>
              {habilidades.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.codigo} — {h.titulo}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Enunciado */}
        <div>
          <label className="text-sm font-semibold text-slate-900">
            Enunciado <ReqStar />
          </label>
          <div className="mt-2">
            <RichEditor editor={enunciadoEd.editor} placeholder="Digite o enunciado…" />
          </div>
        </div>

        {/* Apoio */}
        <Accordion
          title="Apoio"
          subtitle="Texto de apoio + imagem de apoio (opcionais)"
          defaultOpen={false}
        >
          <div>
            <label className="text-sm font-semibold text-slate-900">
              Texto de apoio (opcional)
            </label>
            <div className="mt-2">
              <RichEditor editor={textoApoioEd.editor} placeholder="Se houver texto base, cole aqui…" />
            </div>
          </div>

          <div className="mt-5">
            <label className="text-sm font-semibold text-slate-900">
              Imagem de apoio (opcional)
            </label>

            <div className="mt-2 flex items-start gap-4">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  setSuporteFile(f);
                  setRemoveSuporte(false);

                  if (suportePreview) URL.revokeObjectURL(suportePreview);
                  setSuportePreview(f ? URL.createObjectURL(f) : "");
                }}
                className="block w-full text-sm"
              />

              {(suportePreview || currentSuporteUrl) && !removeSuporte && (
                <img
                  src={suportePreview || currentSuporteUrl}
                  alt="Imagem de apoio"
                  className="h-20 w-20 rounded-lg border border-slate-200 object-cover"
                />
              )}
            </div>

            {!!currentSuporteUrl && (
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setRemoveSuporte(true);
                    setSuporteFile(null);
                    if (suportePreview) URL.revokeObjectURL(suportePreview);
                    setSuportePreview("");
                  }}
                  className="text-sm text-red-600 hover:underline"
                >
                  Remover imagem de apoio
                </button>
                {removeSuporte && (
                  <span className="text-xs text-slate-500">(vai remover ao salvar)</span>
                )}
              </div>
            )}
          </div>

          <div className="mt-4">
            <label className="text-sm font-semibold text-slate-900">
              Referência da imagem (opcional)
            </label>
            <input
              value={refImagem}
              onChange={(e) => setRefImagem(e.target.value)}
              className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-200"
              placeholder="Ex: fonte/autor/link…"
            />
          </div>
        </Accordion>

        {/* Comando */}
        <div>
          <label className="text-sm font-semibold text-slate-900">
            Comando <ReqStar />
          </label>
          <div className="mt-2">
            <RichEditor editor={comandoEd.editor} placeholder="Ex: Assinale a alternativa correta…" />
          </div>

          {triedSubmit && !hasMeaningfulHtml(comandoEd.getHtml()) && (
            <p className="mt-2 text-xs text-red-600">O comando é obrigatório.</p>
          )}
        </div>

        {/* Alternativas */}
        <Accordion
          title={
            <span>
              Alternativas <ReqStar />
            </span>
          }
          defaultOpen={true}
        >
          <div className="space-y-4">
            <div className="flex flex-wrap gap-3">
              {ALT_KEYS.map((k) => {
                const active = altAtiva === k;
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setAltAtiva(k)}
                    className={[
                      "px-5 py-2.5 text-sm rounded-lg transition font-medium border",
                      active
                        ? "bg-emerald-600 text-white border-emerald-600 shadow-sm"
                        : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50",
                    ].join(" ")}
                  >
                    Alternativa {k}
                  </button>
                );
              })}
            </div>

            {altAtiva === "A" && <div><RichEditor editor={altAEd.editor} placeholder="Digite a alternativa…" /><AltImagemUI keyAlt="A" /></div>}
            {altAtiva === "B" && <div><RichEditor editor={altBEd.editor} placeholder="Digite a alternativa…" /><AltImagemUI keyAlt="B" /></div>}
            {altAtiva === "C" && <div><RichEditor editor={altCEd.editor} placeholder="Digite a alternativa…" /><AltImagemUI keyAlt="C" /></div>}
            {altAtiva === "D" && <div><RichEditor editor={altDEd.editor} placeholder="Digite a alternativa…" /><AltImagemUI keyAlt="D" /></div>}
            {altAtiva === "E" && <div><RichEditor editor={altEEd.editor} placeholder="Digite a alternativa…" /><AltImagemUI keyAlt="E" /></div>}

            <div className="mt-5 flex items-center gap-3">
              <label className="text-sm font-semibold text-slate-900">
                Alternativa correta <ReqStar />
              </label>
              <select
                value={altCorreta}
                onChange={(e) => {
                  const v = e.target.value as AlternativaOrEmpty;
                  setAltCorreta(v);
                  if (v) setAltAtiva(v as AltKey);
                }}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-200"
              >
                <option value="" disabled>
                  Selecione…
                </option>
                {ALTS.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </Accordion>

        {/* Rodapé */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-t border-slate-200 pt-4">
          <label className="flex items-center gap-2 text-sm text-slate-700 select-none">
            <input
              type="checkbox"
              checked={isPrivate}
              onChange={(e) => setIsPrivate(e.target.checked)}
              className="h-4 w-4 accent-emerald-600"
            />
            Questão privada
            <span className="text-xs text-slate-500">(somente você consegue usar)</span>
          </label>

          <button
            type="submit"
            disabled={!canSave || saving}
            className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
          >
            {saving ? "Salvando…" : "Salvar alterações"}
          </button>
        </div>
      </form>
    </div>
  );
}
